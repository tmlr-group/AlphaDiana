# Six-Action Statistics Report

## Scope

This report computes statistics for success, failure, and unknown trajectories using the six-action space: Problem Framing, Plan Formation, Solution Execution, Tool Grounding, Result Auditing, and Answer Delivery.

## Source Data Paths

| Benchmark | Harness | Source ID | Source path | Task records |
|---|---|---|---|---:|
| AIME2026 | DirectLLM | `full_aime2026_directllm_kimi_k26_logprobs` | `/data/alphadiana_results_copy/full_aime2026_directllm_kimi_k26_logprobs` | 120 |
| AIME2026 | OpenClaw | `full_aime2026_openclaw_kimi_k26_logprobs` | `/data/alphadiana_results_copy/full_aime2026_openclaw_kimi_k26_logprobs` | 120 |
| AIME2026 | OpenCode | `full_aime2026_opencode_kimi_k26_logprobs` | `/data/alphadiana_results_copy/full_aime2026_opencode_kimi_k26_logprobs` | 120 |
| AIME2026 | ZeroClaw | `full_aime2026_zeroclaw_kimi_k26_logprobs` | `/data/alphadiana_results_copy/full_aime2026_zeroclaw_kimi_k26_logprobs` | 120 |
| MMMU-Pro | DirectLLM | `rollout_full_directllm_mmmu_pro_vision` | `/data/alphadiana_results_copy/full_directllm_mmmu_pro_vision/rollout_full_directllm_mmmu_pro_vision` | 1730 |
| GPQA | DirectLLM | `full_gpqa_directllm_kimi_k26_logprobs` | `/data/alphadiana_results_copy/full_gpqa_directllm_kimi_k26_logprobs` | 198 |
| GPQA | OpenClaw | `full_gpqa_openclaw_kimi_k26_logprobs` | `/data/alphadiana_results_copy/full_gpqa_openclaw_kimi_k26_logprobs` | 198 |
| GPQA | OpenCode | `full_gpqa_opencode_kimi_k26_logprobs` | `/data/alphadiana_results_copy/full_gpqa_opencode_kimi_k26_logprobs` | 198 |
| GPQA | ZeroClaw | `full_gpqa_zeroclaw_kimi_k26_logprobs` | `/data/alphadiana_results_copy/full_gpqa_zeroclaw_kimi_k26_logprobs` | 198 |
| IMO | DirectLLM | `full_imo_directllm_kimi_k26_logprobs` | `/data/alphadiana_results_copy/full_imo_directllm_kimi_k26_logprobs` | 400 |
| IMO | OpenClaw | `full_imo_openclaw_kimi_k26_logprobs` | `/data/alphadiana_results_copy/full_imo_openclaw_kimi_k26_logprobs` | 400 |
| IMO | OpenCode | `full_imo_opencode_kimi_k26_logprobs` | `/data/alphadiana_results_copy/full_imo_opencode_kimi_k26_logprobs` | 400 |
| IMO | ZeroClaw | `full_imo_zeroclaw_kimi_k26_logprobs` | `/data/alphadiana_results_copy/full_imo_zeroclaw_kimi_k26_logprobs` | 400 |
| MMMU-Pro | OpenClaw | `full_mmmu_pro_openclaw_qwen35_27b_logprobs` | `/data/alphadiana_results_copy/full_mmmu_pro_openclaw_qwen35_27b_logprobs` | 1730 |
| MMMU-Pro | OpenCode | `full_mmmu_pro_opencode_qwen35_27b_logprobs` | `/data/alphadiana_results_copy/full_mmmu_pro_opencode_qwen35_27b_logprobs` | 1730 |
| MMMU-Pro | ZeroClaw | `full_mmmu_pro_zeroclaw_qwen35_27b_logprobs` | `/data/alphadiana_results_copy/full_mmmu_pro_zeroclaw_qwen35_27b_logprobs` | 1730 |
| IMO | OpenClaw | `merged_imo_openclaw_qwen35_27b_600_1200` | `/data/alphadiana_results_copy/merged_imo_openclaw_qwen35_27b_600_1200` | 400 |
| IMO | OpenCode | `merged_imo_opencode_qwen35_27b_600_1200` | `/data/alphadiana_results_copy/merged_imo_opencode_qwen35_27b_600_1200` | 400 |
| IMO | ZeroClaw | `merged_imo_zeroclaw_qwen35_27b_600_1200` | `/data/alphadiana_results_copy/merged_imo_zeroclaw_qwen35_27b_600_1200` | 400 |
| HLE | DirectLLM | `full_hle_directllm_kimi_k26_logprobs` | `/data/alphadiana_results_copy/results/full_hle_directllm_kimi_k26_logprobs` | 591 |
| HLE | OpenClaw | `full_hle_openclaw_kimi_k26_logprobs` | `/data/alphadiana_results_copy/results/full_hle_openclaw_kimi_k26_logprobs` | 591 |
| HLE | OpenCode | `full_hle_opencode_kimi_k26_logprobs` | `/data/alphadiana_results_copy/results/full_hle_opencode_kimi_k26_logprobs` | 591 |
| HLE | ZeroClaw | `full_hle_zeroclaw_kimi_k26_logprobs` | `/data/alphadiana_results_copy/results/full_hle_zeroclaw_kimi_k26_logprobs` | 591 |
| MMMU-Pro | DirectLLM | `full_mmmu_pro_directllm_kimi_k26_logprobs` | `/data/alphadiana_results_copy/results/full_mmmu_pro_directllm_kimi_k26_logprobs` | 1730 |
| MMMU-Pro | OpenClaw | `full_mmmu_pro_openclaw_kimi_k26_logprobs` | `/data/alphadiana_results_copy/results/full_mmmu_pro_openclaw_kimi_k26_logprobs` | 1730 |
| MMMU-Pro | OpenCode | `full_mmmu_pro_opencode_kimi_k26_logprobs` | `/data/alphadiana_results_copy/results/full_mmmu_pro_opencode_kimi_k26_logprobs` | 1730 |
| MMMU-Pro | ZeroClaw | `full_mmmu_pro_zeroclaw_kimi_k26_logprobs` | `/data/alphadiana_results_copy/results/full_mmmu_pro_zeroclaw_kimi_k26_logprobs` | 1730 |

## Extraction Logic

- Task records are loaded from each result store's `tasks/*.json` files.
- List-valued task files are treated as multiple sample trajectories. This is required for AIME Pass@4.
- Outcome is `success` when `correct is True`, `failure` when `correct is False`, and `unknown` otherwise.
- Action spans are extracted with `compute_six_action_frequencies.py`: system/user/tool-result-only rows are excluded; assistant text is segmented; tool-call events are retained.
- Action transition counts are computed per trajectory as `__START__ -> first_action -> ... -> last_action -> __END__`.
- Entropy uses `token_entropy_stats.mean`, `max`, `p50`, and `p90` when present.
- Token length uses `token_entropy_stats.n_tokens`, falling back to completion token usage when available.
- Tool type extraction reads task-level tool events. For OpenCode, it also attempts `artifacts/<task_id>/workspace/opencode_output.jsonl` to recover tool names such as `bash`.
- Tool type transitions are computed per trajectory as `__START__ -> first_tool_type -> ... -> last_tool_type -> __END__`.

## Calculation Logic

- `action_counts_by_outcome.csv`: count action event rows by benchmark, harness, outcome, and action.
- `action_transitions_by_outcome.csv`: count adjacent action pairs by benchmark, harness, and outcome.
- `entropy_token_summary_by_outcome.csv`: summary statistics for entropy, token length, wall time, action-event count, and tool-call count.
- `tool_type_counts_by_outcome.csv`: count tool events by benchmark, harness, outcome, and inferred tool type.
- `tool_type_transitions_by_outcome.csv`: count adjacent tool-type pairs by benchmark, harness, and outcome.

## Failure Case Summary

| Benchmark | Harness | Failure traj. | Mean tokens | Mean entropy | Mean actions | Mean tools | Top action | Top tool | Extraction failures |
|---|---|---:|---:|---:|---:|---:|---|---|---|
| AIME2026 | DirectLLM | 17 | 21087.400000 | 0.000000 | 0.117647 | 0.000000 | Solution Execution |  | missing_token_length=4; no_action_events=21 |
| AIME2026 | OpenClaw | 33 |  | 0.000000 | 1.969697 | 1.969697 | Tool Grounding | python | missing_token_length=120; no_action_events=5 |
| AIME2026 | OpenCode | 16 |  | 0.000000 | 25.500000 | 6.562500 | Plan Formation | python | missing_token_length=120 |
| AIME2026 | ZeroClaw | 3 |  | 0.000000 | 46.000000 | 0.000000 | Solution Execution |  | missing_token_length=120 |
| GPQA | DirectLLM | 44 | 20717.075000 | 0.000000 | 0.909091 | 0.000000 | Solution Execution |  | missing_token_length=9; no_action_events=40 |
| GPQA | OpenClaw | 109 |  | 0.000000 | 1.422018 | 1.082569 | Tool Grounding | web_fetch | missing_token_length=198; no_action_events=77 |
| GPQA | OpenCode | 38 |  | 0.000000 | 17.078947 | 5.710526 | Plan Formation | web_fetch | missing_token_length=198 |
| GPQA | ZeroClaw | 22 |  | 0.000000 | 12.818182 | 0.000000 | Solution Execution |  | missing_token_length=198 |
| HLE | DirectLLM | 376 | 20021.774194 | 0.011618 | 1.726064 | 0.000000 | Answer Delivery |  | missing_entropy=4; missing_token_length=10; no_action_events=34 |
| HLE | OpenClaw | 147 |  | 0.000000 | 13.870748 | 6.476190 | Tool Grounding | web_fetch | missing_token_length=591; no_action_events=76 |
| HLE | OpenCode | 423 |  | 0.000000 | 21.056738 | 8.650118 | Tool Grounding | web_fetch | missing_token_length=591 |
| HLE | ZeroClaw | 353 |  | 0.000000 | 17.498584 | 0.000000 | Solution Execution |  | missing_token_length=591 |
| IMO | DirectLLM | 232 | 25690.570755 | 0.000332 | 8.159483 | 0.000000 | Solution Execution |  | missing_token_length=28; no_action_events=154 |
| IMO | OpenClaw | 610 | 16567.099678 | 0.035197 | 171.445902 | 2.468852 | Solution Execution | python | missing_token_length=408; no_action_events=20 |
| IMO | OpenCode | 536 | 13679.884848 | 0.059770 | 183.270522 | 4.108209 | Solution Execution | python | missing_token_length=400 |
| IMO | ZeroClaw | 454 | 4992.302632 | 0.029156 | 26.244493 | 0.000000 | Solution Execution |  | missing_token_length=661 |
| MMMU-Pro | DirectLLM | 851 | 21596.281100 | 0.122919 | 401.591069 | 0.000000 | Solution Execution |  | missing_entropy=40; missing_token_length=63; no_action_events=57 |
| MMMU-Pro | OpenClaw | 744 | 4347.808880 | 0.188672 | 64.138441 | 2.306452 | Solution Execution | web_fetch | missing_token_length=1731; no_action_events=143 |
| MMMU-Pro | OpenCode | 909 | 2130.264563 | 0.161679 | 32.299230 | 2.896590 | Solution Execution | web_fetch | missing_token_length=1730 |
| MMMU-Pro | ZeroClaw | 824 | 2923.315789 | 0.164845 | 30.969660 | 0.000000 | Solution Execution |  | missing_token_length=1823; no_action_events=73 |

## Action Count Preview

| Benchmark | Harness | Outcome | Action | Count |
|---|---|---|---|---:|
| AIME2026 | DirectLLM | failure | Solution Execution | 2 |
| AIME2026 | DirectLLM | success | Answer Delivery | 100 |
| AIME2026 | DirectLLM | success | Plan Formation | 161 |
| AIME2026 | DirectLLM | success | Problem Framing | 5 |
| AIME2026 | DirectLLM | success | Result Auditing | 4 |
| AIME2026 | DirectLLM | success | Solution Execution | 1080 |
| AIME2026 | OpenClaw | failure | Tool Grounding | 65 |
| AIME2026 | OpenClaw | success | Answer Delivery | 75 |
| AIME2026 | OpenClaw | success | Plan Formation | 87 |
| AIME2026 | OpenClaw | success | Result Auditing | 12 |
| AIME2026 | OpenClaw | success | Solution Execution | 704 |
| AIME2026 | OpenClaw | success | Tool Grounding | 322 |
| AIME2026 | OpenCode | failure | Answer Delivery | 4 |
| AIME2026 | OpenCode | failure | Plan Formation | 232 |
| AIME2026 | OpenCode | failure | Result Auditing | 13 |
| AIME2026 | OpenCode | failure | Solution Execution | 75 |
| AIME2026 | OpenCode | failure | Tool Grounding | 84 |
| AIME2026 | OpenCode | success | Answer Delivery | 206 |
| AIME2026 | OpenCode | success | Plan Formation | 94 |
| AIME2026 | OpenCode | success | Result Auditing | 14 |
| AIME2026 | OpenCode | success | Solution Execution | 904 |
| AIME2026 | OpenCode | success | Tool Grounding | 451 |
| AIME2026 | ZeroClaw | failure | Plan Formation | 2 |
| AIME2026 | ZeroClaw | failure | Result Auditing | 16 |
| AIME2026 | ZeroClaw | failure | Solution Execution | 120 |
| AIME2026 | ZeroClaw | success | Answer Delivery | 113 |
| AIME2026 | ZeroClaw | success | Plan Formation | 95 |
| AIME2026 | ZeroClaw | success | Problem Framing | 4 |
| AIME2026 | ZeroClaw | success | Result Auditing | 122 |
| AIME2026 | ZeroClaw | success | Solution Execution | 1181 |
| AIME2026 | ZeroClaw | unknown | Result Auditing | 4 |
| AIME2026 | ZeroClaw | unknown | Solution Execution | 19 |
| GPQA | DirectLLM | failure | Answer Delivery | 8 |
| GPQA | DirectLLM | failure | Plan Formation | 1 |
| GPQA | DirectLLM | failure | Result Auditing | 3 |
| GPQA | DirectLLM | failure | Solution Execution | 28 |
| GPQA | DirectLLM | success | Answer Delivery | 152 |
| GPQA | DirectLLM | success | Plan Formation | 95 |
| GPQA | DirectLLM | success | Problem Framing | 13 |
| GPQA | DirectLLM | success | Result Auditing | 11 |
| GPQA | DirectLLM | success | Solution Execution | 942 |
| GPQA | OpenClaw | failure | Answer Delivery | 5 |
| GPQA | OpenClaw | failure | Plan Formation | 3 |
| GPQA | OpenClaw | failure | Solution Execution | 37 |
| GPQA | OpenClaw | failure | Tool Grounding | 110 |
| GPQA | OpenClaw | success | Answer Delivery | 80 |
| GPQA | OpenClaw | success | Plan Formation | 47 |
| GPQA | OpenClaw | success | Problem Framing | 8 |
| GPQA | OpenClaw | success | Result Auditing | 10 |
| GPQA | OpenClaw | success | Solution Execution | 444 |
| GPQA | OpenClaw | success | Tool Grounding | 200 |
| GPQA | OpenClaw | unknown | Result Auditing | 6 |
| GPQA | OpenCode | failure | Answer Delivery | 24 |
| GPQA | OpenCode | failure | Plan Formation | 243 |
| GPQA | OpenCode | failure | Problem Framing | 2 |
| GPQA | OpenCode | failure | Result Auditing | 50 |
| GPQA | OpenCode | failure | Solution Execution | 142 |
| GPQA | OpenCode | failure | Tool Grounding | 188 |
| GPQA | OpenCode | success | Answer Delivery | 322 |
| GPQA | OpenCode | success | Plan Formation | 99 |
| GPQA | OpenCode | success | Problem Framing | 8 |
| GPQA | OpenCode | success | Result Auditing | 32 |
| GPQA | OpenCode | success | Solution Execution | 1034 |
| GPQA | OpenCode | success | Tool Grounding | 572 |
| GPQA | ZeroClaw | failure | Answer Delivery | 17 |
| GPQA | ZeroClaw | failure | Plan Formation | 21 |
| GPQA | ZeroClaw | failure | Problem Framing | 4 |
| GPQA | ZeroClaw | failure | Result Auditing | 65 |
| GPQA | ZeroClaw | failure | Solution Execution | 175 |
| GPQA | ZeroClaw | success | Answer Delivery | 174 |
| GPQA | ZeroClaw | success | Plan Formation | 339 |
| GPQA | ZeroClaw | success | Problem Framing | 30 |

## Entropy and Token Preview

| Benchmark | Harness | Outcome | Metric | N | Missing | Mean | Median | P75 |
|---|---|---|---|---:|---:|---:|---:|---:|
| AIME2026 | DirectLLM | failure | mean_entropy | 17 | 0 | 0.000000 | 0.000000 | 0.000000 |
| AIME2026 | DirectLLM | failure | n_tokens | 15 | 2 | 21087.400000 | 22790.000000 | 25515.000000 |
| AIME2026 | DirectLLM | failure | action_event_count | 17 | 0 | 0.117647 | 0.000000 | 0.000000 |
| AIME2026 | DirectLLM | failure | tool_call_count | 17 | 0 | 0.000000 | 0.000000 | 0.000000 |
| AIME2026 | DirectLLM | success | mean_entropy | 103 | 0 | 0.003284 | 0.000000 | 0.000000 |
| AIME2026 | DirectLLM | success | n_tokens | 101 | 2 | 15205.376238 | 13471.000000 | 20359.000000 |
| AIME2026 | DirectLLM | success | action_event_count | 103 | 0 | 13.106796 | 11.000000 | 17.000000 |
| AIME2026 | DirectLLM | success | tool_call_count | 103 | 0 | 0.000000 | 0.000000 | 0.000000 |
| AIME2026 | OpenClaw | failure | mean_entropy | 33 | 0 | 0.000000 | 0.000000 | 0.000000 |
| AIME2026 | OpenClaw | failure | n_tokens | 0 | 33 |  |  |  |
| AIME2026 | OpenClaw | failure | action_event_count | 33 | 0 | 1.969697 | 1.000000 | 2.000000 |
| AIME2026 | OpenClaw | failure | tool_call_count | 33 | 0 | 1.969697 | 1.000000 | 2.000000 |
| AIME2026 | OpenClaw | success | mean_entropy | 87 | 0 | 0.000000 | 0.000000 | 0.000000 |
| AIME2026 | OpenClaw | success | n_tokens | 0 | 87 |  |  |  |
| AIME2026 | OpenClaw | success | action_event_count | 87 | 0 | 13.793103 | 12.000000 | 18.000000 |
| AIME2026 | OpenClaw | success | tool_call_count | 87 | 0 | 3.954023 | 2.000000 | 5.000000 |
| AIME2026 | OpenCode | failure | mean_entropy | 16 | 0 | 0.000000 | 0.000000 | 0.000000 |
| AIME2026 | OpenCode | failure | n_tokens | 0 | 16 |  |  |  |
| AIME2026 | OpenCode | failure | action_event_count | 16 | 0 | 25.500000 | 12.000000 | 39.250000 |
| AIME2026 | OpenCode | failure | tool_call_count | 16 | 0 | 6.562500 | 7.000000 | 9.000000 |
| AIME2026 | OpenCode | success | mean_entropy | 104 | 0 | 0.000000 | 0.000000 | 0.000000 |
| AIME2026 | OpenCode | success | n_tokens | 0 | 104 |  |  |  |
| AIME2026 | OpenCode | success | action_event_count | 104 | 0 | 16.048077 | 13.500000 | 22.250000 |
| AIME2026 | OpenCode | success | tool_call_count | 104 | 0 | 4.721154 | 3.000000 | 5.000000 |
| AIME2026 | ZeroClaw | failure | mean_entropy | 3 | 0 | 0.000000 | 0.000000 | 0.000000 |
| AIME2026 | ZeroClaw | failure | n_tokens | 0 | 3 |  |  |  |
| AIME2026 | ZeroClaw | failure | action_event_count | 3 | 0 | 46.000000 | 46.000000 | 62.000000 |
| AIME2026 | ZeroClaw | failure | tool_call_count | 3 | 0 | 0.000000 | 0.000000 | 0.000000 |
| AIME2026 | ZeroClaw | success | mean_entropy | 112 | 0 | 0.000000 | 0.000000 | 0.000000 |
| AIME2026 | ZeroClaw | success | n_tokens | 0 | 112 |  |  |  |
| AIME2026 | ZeroClaw | success | action_event_count | 112 | 0 | 13.526786 | 10.000000 | 15.000000 |
| AIME2026 | ZeroClaw | success | tool_call_count | 112 | 0 | 0.000000 | 0.000000 | 0.000000 |
| AIME2026 | ZeroClaw | unknown | mean_entropy | 5 | 0 | 0.000000 | 0.000000 | 0.000000 |
| AIME2026 | ZeroClaw | unknown | n_tokens | 0 | 5 |  |  |  |
| AIME2026 | ZeroClaw | unknown | action_event_count | 5 | 0 | 4.600000 | 2.000000 | 7.000000 |
| AIME2026 | ZeroClaw | unknown | tool_call_count | 5 | 0 | 0.000000 | 0.000000 | 0.000000 |
| GPQA | DirectLLM | failure | mean_entropy | 44 | 0 | 0.000000 | 0.000000 | 0.000000 |
| GPQA | DirectLLM | failure | n_tokens | 40 | 4 | 20717.075000 | 22681.000000 | 27401.250000 |
| GPQA | DirectLLM | failure | action_event_count | 44 | 0 | 0.909091 | 0.000000 | 0.000000 |
| GPQA | DirectLLM | failure | tool_call_count | 44 | 0 | 0.000000 | 0.000000 | 0.000000 |
| GPQA | DirectLLM | success | mean_entropy | 154 | 0 | 0.007202 | 0.000000 | 0.000000 |
| GPQA | DirectLLM | success | n_tokens | 149 | 5 | 11954.523490 | 8741.000000 | 17902.000000 |
| GPQA | DirectLLM | success | action_event_count | 154 | 0 | 7.876623 | 7.000000 | 10.000000 |
| GPQA | DirectLLM | success | tool_call_count | 154 | 0 | 0.000000 | 0.000000 | 0.000000 |
| GPQA | OpenClaw | failure | mean_entropy | 109 | 0 | 0.000000 | 0.000000 | 0.000000 |
| GPQA | OpenClaw | failure | n_tokens | 0 | 109 |  |  |  |
| GPQA | OpenClaw | failure | action_event_count | 109 | 0 | 1.422018 | 0.000000 | 1.000000 |
| GPQA | OpenClaw | failure | tool_call_count | 109 | 0 | 1.082569 | 0.000000 | 1.000000 |
| GPQA | OpenClaw | success | mean_entropy | 82 | 0 | 0.000000 | 0.000000 | 0.000000 |
| GPQA | OpenClaw | success | n_tokens | 0 | 82 |  |  |  |
| GPQA | OpenClaw | success | action_event_count | 82 | 0 | 9.621951 | 9.000000 | 12.750000 |
| GPQA | OpenClaw | success | tool_call_count | 82 | 0 | 2.524390 | 1.000000 | 2.000000 |
| GPQA | OpenClaw | unknown | mean_entropy | 7 | 0 | 0.000000 | 0.000000 | 0.000000 |
| GPQA | OpenClaw | unknown | n_tokens | 0 | 7 |  |  |  |
| GPQA | OpenClaw | unknown | action_event_count | 7 | 0 | 0.857143 | 1.000000 | 1.000000 |
| GPQA | OpenClaw | unknown | tool_call_count | 7 | 0 | 0.000000 | 0.000000 | 0.000000 |
| GPQA | OpenCode | failure | mean_entropy | 38 | 0 | 0.000000 | 0.000000 | 0.000000 |
| GPQA | OpenCode | failure | n_tokens | 0 | 38 |  |  |  |
| GPQA | OpenCode | failure | action_event_count | 38 | 0 | 17.078947 | 12.000000 | 26.000000 |
| GPQA | OpenCode | failure | tool_call_count | 38 | 0 | 5.710526 | 2.000000 | 8.000000 |
| GPQA | OpenCode | success | mean_entropy | 160 | 0 | 0.000000 | 0.000000 | 0.000000 |
| GPQA | OpenCode | success | n_tokens | 0 | 160 |  |  |  |
| GPQA | OpenCode | success | action_event_count | 160 | 0 | 12.918750 | 12.000000 | 17.000000 |
| GPQA | OpenCode | success | tool_call_count | 160 | 0 | 3.787500 | 2.000000 | 5.000000 |
| GPQA | ZeroClaw | failure | mean_entropy | 22 | 0 | 0.000000 | 0.000000 | 0.000000 |
| GPQA | ZeroClaw | failure | n_tokens | 0 | 22 |  |  |  |
| GPQA | ZeroClaw | failure | action_event_count | 22 | 0 | 12.818182 | 10.000000 | 15.500000 |
| GPQA | ZeroClaw | failure | tool_call_count | 22 | 0 | 0.000000 | 0.000000 | 0.000000 |
| GPQA | ZeroClaw | success | mean_entropy | 173 | 0 | 0.000000 | 0.000000 | 0.000000 |
| GPQA | ZeroClaw | success | n_tokens | 0 | 173 |  |  |  |
| GPQA | ZeroClaw | success | action_event_count | 173 | 0 | 12.063584 | 10.000000 | 13.000000 |
| GPQA | ZeroClaw | success | tool_call_count | 173 | 0 | 0.000000 | 0.000000 | 0.000000 |
| GPQA | ZeroClaw | unknown | mean_entropy | 3 | 0 | 0.000000 | 0.000000 | 0.000000 |
| GPQA | ZeroClaw | unknown | n_tokens | 0 | 3 |  |  |  |
| GPQA | ZeroClaw | unknown | action_event_count | 3 | 0 | 15.666667 | 2.000000 | 22.500000 |
| GPQA | ZeroClaw | unknown | tool_call_count | 3 | 0 | 0.000000 | 0.000000 | 0.000000 |
| HLE | DirectLLM | failure | mean_entropy | 376 | 0 | 0.011618 | 0.000000 | 0.000000 |
| HLE | DirectLLM | failure | n_tokens | 372 | 4 | 20021.774194 | 15144.000000 | 29658.000000 |
| HLE | DirectLLM | failure | action_event_count | 376 | 0 | 1.726064 | 1.000000 | 1.000000 |
| HLE | DirectLLM | failure | tool_call_count | 376 | 0 | 0.000000 | 0.000000 | 0.000000 |
| HLE | DirectLLM | success | mean_entropy | 211 | 0 | 0.006319 | 0.000000 | 0.000000 |
| HLE | DirectLLM | success | n_tokens | 209 | 2 | 22019.827751 | 18046.000000 | 29644.000000 |
| HLE | DirectLLM | success | action_event_count | 211 | 0 | 1.872038 | 1.000000 | 1.000000 |
| HLE | DirectLLM | success | tool_call_count | 211 | 0 | 0.000000 | 0.000000 | 0.000000 |
| HLE | DirectLLM | unknown | mean_entropy | 0 | 4 |  |  |  |
| HLE | DirectLLM | unknown | n_tokens | 0 | 4 |  |  |  |
| HLE | DirectLLM | unknown | action_event_count | 4 | 0 | 0.000000 | 0.000000 | 0.000000 |
| HLE | DirectLLM | unknown | tool_call_count | 4 | 0 | 0.000000 | 0.000000 | 0.000000 |
| HLE | OpenClaw | failure | mean_entropy | 147 | 0 | 0.000000 | 0.000000 | 0.000000 |
| HLE | OpenClaw | failure | n_tokens | 0 | 147 |  |  |  |
| HLE | OpenClaw | failure | action_event_count | 147 | 0 | 13.870748 | 11.000000 | 16.000000 |
| HLE | OpenClaw | failure | tool_call_count | 147 | 0 | 6.476190 | 2.000000 | 6.000000 |
| HLE | OpenClaw | success | mean_entropy | 101 | 0 | 0.000000 | 0.000000 | 0.000000 |
| HLE | OpenClaw | success | n_tokens | 0 | 101 |  |  |  |
| HLE | OpenClaw | success | action_event_count | 101 | 0 | 18.346535 | 13.000000 | 20.000000 |
| HLE | OpenClaw | success | tool_call_count | 101 | 0 | 11.693069 | 3.000000 | 12.000000 |
| HLE | OpenClaw | unknown | mean_entropy | 343 | 0 | 0.000000 | 0.000000 | 0.000000 |
| HLE | OpenClaw | unknown | n_tokens | 0 | 343 |  |  |  |
| HLE | OpenClaw | unknown | action_event_count | 343 | 0 | 1.081633 | 1.000000 | 1.000000 |
| HLE | OpenClaw | unknown | tool_call_count | 343 | 0 | 0.411079 | 0.000000 | 0.000000 |
| HLE | OpenCode | failure | mean_entropy | 423 | 0 | 0.000000 | 0.000000 | 0.000000 |
| HLE | OpenCode | failure | n_tokens | 0 | 423 |  |  |  |
| HLE | OpenCode | failure | action_event_count | 423 | 0 | 21.056738 | 13.000000 | 22.000000 |
| HLE | OpenCode | failure | tool_call_count | 423 | 0 | 8.650118 | 4.000000 | 10.000000 |
| HLE | OpenCode | success | mean_entropy | 167 | 0 | 0.000000 | 0.000000 | 0.000000 |
| HLE | OpenCode | success | n_tokens | 0 | 167 |  |  |  |
| HLE | OpenCode | success | action_event_count | 167 | 0 | 16.311377 | 13.000000 | 22.000000 |
| HLE | OpenCode | success | tool_call_count | 167 | 0 | 8.814371 | 5.000000 | 12.500000 |
| HLE | OpenCode | unknown | mean_entropy | 1 | 0 | 0.000000 | 0.000000 | 0.000000 |
| HLE | OpenCode | unknown | n_tokens | 0 | 1 |  |  |  |
| HLE | OpenCode | unknown | action_event_count | 1 | 0 | 17.000000 | 17.000000 | 17.000000 |
| HLE | OpenCode | unknown | tool_call_count | 1 | 0 | 11.000000 | 11.000000 | 11.000000 |
| HLE | ZeroClaw | failure | mean_entropy | 353 | 0 | 0.000000 | 0.000000 | 0.000000 |
| HLE | ZeroClaw | failure | n_tokens | 0 | 353 |  |  |  |
| HLE | ZeroClaw | failure | action_event_count | 353 | 0 | 17.498584 | 10.000000 | 14.000000 |
| HLE | ZeroClaw | failure | tool_call_count | 353 | 0 | 0.000000 | 0.000000 | 0.000000 |
| HLE | ZeroClaw | success | mean_entropy | 163 | 0 | 0.000000 | 0.000000 | 0.000000 |
| HLE | ZeroClaw | success | n_tokens | 0 | 163 |  |  |  |
| HLE | ZeroClaw | success | action_event_count | 163 | 0 | 13.000000 | 11.000000 | 14.500000 |
| HLE | ZeroClaw | success | tool_call_count | 163 | 0 | 0.000000 | 0.000000 | 0.000000 |
| HLE | ZeroClaw | unknown | mean_entropy | 75 | 0 | 0.000000 | 0.000000 | 0.000000 |
| HLE | ZeroClaw | unknown | n_tokens | 0 | 75 |  |  |  |
| HLE | ZeroClaw | unknown | action_event_count | 75 | 0 | 21.946667 | 2.000000 | 13.000000 |
| HLE | ZeroClaw | unknown | tool_call_count | 75 | 0 | 0.000000 | 0.000000 | 0.000000 |
| IMO | DirectLLM | failure | mean_entropy | 232 | 0 | 0.000332 | 0.000000 | 0.000000 |
| IMO | DirectLLM | failure | n_tokens | 212 | 20 | 25690.570755 | 23304.000000 | 31781.250000 |
| IMO | DirectLLM | failure | action_event_count | 232 | 0 | 8.159483 | 0.000000 | 14.250000 |
| IMO | DirectLLM | failure | tool_call_count | 232 | 0 | 0.000000 | 0.000000 | 0.000000 |
| IMO | DirectLLM | success | mean_entropy | 168 | 0 | 0.003351 | 0.000000 | 0.000000 |
| IMO | DirectLLM | success | n_tokens | 160 | 8 | 26250.612500 | 22012.000000 | 33493.250000 |
| IMO | DirectLLM | success | action_event_count | 168 | 0 | 17.107143 | 14.000000 | 26.000000 |
| IMO | DirectLLM | success | tool_call_count | 168 | 0 | 0.000000 | 0.000000 | 0.000000 |
| IMO | OpenClaw | failure | mean_entropy | 610 | 0 | 0.035197 | 0.000945 | 0.044564 |
| IMO | OpenClaw | failure | n_tokens | 311 | 299 | 16567.099678 | 15233.000000 | 22586.500000 |
| IMO | OpenClaw | failure | action_event_count | 610 | 0 | 171.445902 | 4.000000 | 252.250000 |
| IMO | OpenClaw | failure | tool_call_count | 610 | 0 | 2.468852 | 1.000000 | 3.000000 |
| IMO | OpenClaw | success | mean_entropy | 190 | 0 | 0.079939 | 0.000000 | 0.168840 |
| IMO | OpenClaw | success | n_tokens | 81 | 109 | 4513.234568 | 3511.000000 | 5363.000000 |
| IMO | OpenClaw | success | action_event_count | 190 | 0 | 32.289474 | 17.000000 | 27.000000 |
| IMO | OpenClaw | success | tool_call_count | 190 | 0 | 4.226316 | 2.000000 | 5.000000 |
| IMO | OpenCode | failure | mean_entropy | 536 | 0 | 0.059770 | 0.042336 | 0.081137 |
| IMO | OpenCode | failure | n_tokens | 330 | 206 | 13679.884848 | 14902.000000 | 16962.250000 |
| IMO | OpenCode | failure | action_event_count | 536 | 0 | 183.270522 | 149.500000 | 276.250000 |
| IMO | OpenCode | failure | tool_call_count | 536 | 0 | 4.108209 | 0.000000 | 5.000000 |
| IMO | OpenCode | success | mean_entropy | 264 | 0 | 0.062470 | 0.000000 | 0.116084 |
| IMO | OpenCode | success | n_tokens | 70 | 194 | 3047.814286 | 1790.000000 | 4025.250000 |
| IMO | OpenCode | success | action_event_count | 264 | 0 | 52.962121 | 26.500000 | 62.000000 |
| IMO | OpenCode | success | tool_call_count | 264 | 0 | 6.314394 | 4.000000 | 8.000000 |
| IMO | ZeroClaw | failure | mean_entropy | 454 | 0 | 0.029156 | 0.000000 | 0.000000 |
| IMO | ZeroClaw | failure | n_tokens | 76 | 378 | 4992.302632 | 4064.000000 | 6902.000000 |
| IMO | ZeroClaw | failure | action_event_count | 454 | 0 | 26.244493 | 1.000000 | 28.750000 |
| IMO | ZeroClaw | failure | tool_call_count | 454 | 0 | 0.000000 | 0.000000 | 0.000000 |
| IMO | ZeroClaw | success | mean_entropy | 153 | 0 | 0.056193 | 0.000000 | 0.112472 |
| IMO | ZeroClaw | success | n_tokens | 63 | 90 | 5942.936508 | 4659.000000 | 8403.500000 |
| IMO | ZeroClaw | success | action_event_count | 153 | 0 | 58.366013 | 24.000000 | 63.000000 |
| IMO | ZeroClaw | success | tool_call_count | 153 | 0 | 0.000000 | 0.000000 | 0.000000 |
| IMO | ZeroClaw | unknown | mean_entropy | 193 | 0 | 0.000000 | 0.000000 | 0.000000 |
| IMO | ZeroClaw | unknown | n_tokens | 0 | 193 |  |  |  |
| IMO | ZeroClaw | unknown | action_event_count | 193 | 0 | 2.000000 | 2.000000 | 2.000000 |
| IMO | ZeroClaw | unknown | tool_call_count | 193 | 0 | 0.000000 | 0.000000 | 0.000000 |
| MMMU-Pro | DirectLLM | failure | mean_entropy | 851 | 0 | 0.122919 | 0.028985 | 0.243961 |
| MMMU-Pro | DirectLLM | failure | n_tokens | 836 | 15 | 21596.281100 | 8155.000000 | 19824.250000 |
| MMMU-Pro | DirectLLM | failure | action_event_count | 851 | 0 | 401.591069 | 23.000000 | 169.000000 |
| MMMU-Pro | DirectLLM | failure | tool_call_count | 851 | 0 | 0.000000 | 0.000000 | 0.000000 |
| MMMU-Pro | DirectLLM | success | mean_entropy | 2569 | 0 | 0.103175 | 0.076730 | 0.181182 |
| MMMU-Pro | DirectLLM | success | n_tokens | 2561 | 8 | 5762.581414 | 2796.000000 | 7658.000000 |
| MMMU-Pro | DirectLLM | success | action_event_count | 2569 | 0 | 54.836123 | 11.000000 | 39.000000 |
| MMMU-Pro | DirectLLM | success | tool_call_count | 2569 | 0 | 0.000000 | 0.000000 | 0.000000 |
| MMMU-Pro | DirectLLM | unknown | mean_entropy | 0 | 40 |  |  |  |
| MMMU-Pro | DirectLLM | unknown | n_tokens | 0 | 40 |  |  |  |
| MMMU-Pro | DirectLLM | unknown | action_event_count | 40 | 0 | 0.000000 | 0.000000 | 0.000000 |
| MMMU-Pro | DirectLLM | unknown | tool_call_count | 40 | 0 | 0.000000 | 0.000000 | 0.000000 |
| MMMU-Pro | OpenClaw | failure | mean_entropy | 744 | 0 | 0.188672 | 0.195698 | 0.329752 |
| MMMU-Pro | OpenClaw | failure | n_tokens | 518 | 226 | 4347.808880 | 1471.000000 | 5185.500000 |
| MMMU-Pro | OpenClaw | failure | action_event_count | 744 | 0 | 64.138441 | 20.000000 | 34.250000 |
| MMMU-Pro | OpenClaw | failure | tool_call_count | 744 | 0 | 2.306452 | 0.000000 | 2.000000 |
| MMMU-Pro | OpenClaw | success | mean_entropy | 2022 | 0 | 0.147345 | 0.138548 | 0.268647 |
| MMMU-Pro | OpenClaw | success | n_tokens | 1181 | 841 | 1183.164268 | 956.000000 | 1290.000000 |
| MMMU-Pro | OpenClaw | success | action_event_count | 2022 | 0 | 15.239367 | 12.000000 | 20.000000 |
| MMMU-Pro | OpenClaw | success | tool_call_count | 2022 | 0 | 1.379327 | 1.000000 | 1.000000 |
| MMMU-Pro | OpenClaw | unknown | mean_entropy | 694 | 0 | 0.005085 | 0.000000 | 0.000000 |
| MMMU-Pro | OpenClaw | unknown | n_tokens | 30 | 664 | 11488.733333 | 13331.500000 | 16235.250000 |
| MMMU-Pro | OpenClaw | unknown | action_event_count | 694 | 0 | 11.595101 | 1.000000 | 1.000000 |
| MMMU-Pro | OpenClaw | unknown | tool_call_count | 694 | 0 | 1.233429 | 0.000000 | 0.000000 |
| MMMU-Pro | OpenCode | failure | mean_entropy | 909 | 0 | 0.161679 | 0.000000 | 0.348145 |
| MMMU-Pro | OpenCode | failure | n_tokens | 412 | 497 | 2130.264563 | 801.500000 | 1171.000000 |
| MMMU-Pro | OpenCode | failure | action_event_count | 909 | 0 | 32.299230 | 20.000000 | 40.000000 |
| MMMU-Pro | OpenCode | failure | tool_call_count | 909 | 0 | 2.896590 | 0.000000 | 2.000000 |
| MMMU-Pro | OpenCode | success | mean_entropy | 2434 | 0 | 0.131579 | 0.000000 | 0.258640 |
| MMMU-Pro | OpenCode | success | n_tokens | 1201 | 1233 | 833.591174 | 697.000000 | 938.000000 |
| MMMU-Pro | OpenCode | success | action_event_count | 2434 | 0 | 23.263763 | 16.000000 | 32.000000 |
| MMMU-Pro | OpenCode | success | tool_call_count | 2434 | 0 | 1.444125 | 0.000000 | 1.000000 |
| MMMU-Pro | OpenCode | unknown | mean_entropy | 117 | 0 | 0.140770 | 0.099924 | 0.181982 |
| MMMU-Pro | OpenCode | unknown | n_tokens | 117 | 0 | 7760.119658 | 8566.000000 | 10638.000000 |
| MMMU-Pro | OpenCode | unknown | action_event_count | 117 | 0 | 152.256410 | 139.000000 | 187.000000 |
| MMMU-Pro | OpenCode | unknown | tool_call_count | 117 | 0 | 3.256410 | 0.000000 | 2.000000 |
| MMMU-Pro | ZeroClaw | failure | mean_entropy | 824 | 0 | 0.164845 | 0.155434 | 0.312369 |
| MMMU-Pro | ZeroClaw | failure | n_tokens | 475 | 349 | 2923.315789 | 1365.000000 | 3117.500000 |
| MMMU-Pro | ZeroClaw | failure | action_event_count | 824 | 0 | 30.969660 | 15.000000 | 28.000000 |
| MMMU-Pro | ZeroClaw | failure | tool_call_count | 824 | 0 | 0.000000 | 0.000000 | 0.000000 |
| MMMU-Pro | ZeroClaw | success | mean_entropy | 2281 | 0 | 0.113716 | 0.064691 | 0.221226 |
| MMMU-Pro | ZeroClaw | success | n_tokens | 1162 | 1119 | 1759.426850 | 1119.500000 | 1834.250000 |
| MMMU-Pro | ZeroClaw | success | action_event_count | 2281 | 0 | 18.650592 | 12.000000 | 23.000000 |
| MMMU-Pro | ZeroClaw | success | tool_call_count | 2281 | 0 | 0.000000 | 0.000000 | 0.000000 |
| MMMU-Pro | ZeroClaw | unknown | mean_entropy | 355 | 0 | 0.000000 | 0.000000 | 0.000000 |
| MMMU-Pro | ZeroClaw | unknown | n_tokens | 0 | 355 |  |  |  |
| MMMU-Pro | ZeroClaw | unknown | action_event_count | 355 | 0 | 3.712676 | 2.000000 | 2.000000 |
| MMMU-Pro | ZeroClaw | unknown | tool_call_count | 355 | 0 | 0.000000 | 0.000000 | 0.000000 |

## Tool Count Preview

| Benchmark | Harness | Outcome | Tool type | Count |
|---|---|---|---|---:|
| AIME2026 | OpenClaw | failure | bash | 3 |
| AIME2026 | OpenClaw | failure | python | 50 |
| AIME2026 | OpenClaw | failure | read | 1 |
| AIME2026 | OpenClaw | failure | search | 3 |
| AIME2026 | OpenClaw | failure | tool | 1 |
| AIME2026 | OpenClaw | failure | web_fetch | 7 |
| AIME2026 | OpenClaw | success | bash | 26 |
| AIME2026 | OpenClaw | success | python | 242 |
| AIME2026 | OpenClaw | success | read | 7 |
| AIME2026 | OpenClaw | success | search | 23 |
| AIME2026 | OpenClaw | success | web_fetch | 35 |
| AIME2026 | OpenClaw | success | write | 11 |
| AIME2026 | OpenCode | failure | python | 84 |
| AIME2026 | OpenCode | failure | web_fetch | 18 |
| AIME2026 | OpenCode | failure | write | 3 |
| AIME2026 | OpenCode | success | bash | 4 |
| AIME2026 | OpenCode | success | python | 428 |
| AIME2026 | OpenCode | success | tool | 12 |
| AIME2026 | OpenCode | success | web_fetch | 46 |
| AIME2026 | OpenCode | success | write | 1 |
| GPQA | OpenClaw | failure | bash | 6 |
| GPQA | OpenClaw | failure | edit | 1 |
| GPQA | OpenClaw | failure | python | 36 |
| GPQA | OpenClaw | failure | search | 29 |
| GPQA | OpenClaw | failure | tool | 3 |
| GPQA | OpenClaw | failure | web_fetch | 40 |
| GPQA | OpenClaw | failure | write | 3 |
| GPQA | OpenClaw | success | bash | 28 |
| GPQA | OpenClaw | success | edit | 1 |
| GPQA | OpenClaw | success | python | 76 |
| GPQA | OpenClaw | success | read | 2 |
| GPQA | OpenClaw | success | search | 35 |
| GPQA | OpenClaw | success | tool | 1 |
| GPQA | OpenClaw | success | web_fetch | 63 |
| GPQA | OpenClaw | success | write | 1 |
| GPQA | OpenCode | failure | bash | 10 |
| GPQA | OpenCode | failure | glob | 1 |
| GPQA | OpenCode | failure | python | 39 |
| GPQA | OpenCode | failure | read | 1 |
| GPQA | OpenCode | failure | search | 22 |
| GPQA | OpenCode | failure | task | 4 |
| GPQA | OpenCode | failure | web_fetch | 134 |
| GPQA | OpenCode | failure | write | 6 |
| GPQA | OpenCode | success | bash | 25 |
| GPQA | OpenCode | success | glob | 1 |
| GPQA | OpenCode | success | invalid | 2 |
| GPQA | OpenCode | success | python | 241 |
| GPQA | OpenCode | success | read | 3 |
| GPQA | OpenCode | success | search | 2 |
| GPQA | OpenCode | success | task | 7 |
| GPQA | OpenCode | success | web_fetch | 314 |
| GPQA | OpenCode | success | write | 11 |
| HLE | OpenClaw | failure | bash | 89 |
| HLE | OpenClaw | failure | python | 194 |
| HLE | OpenClaw | failure | read | 16 |
| HLE | OpenClaw | failure | search | 249 |
| HLE | OpenClaw | failure | tool | 62 |
| HLE | OpenClaw | failure | web_fetch | 333 |
| HLE | OpenClaw | failure | write | 9 |
| HLE | OpenClaw | success | bash | 161 |
| HLE | OpenClaw | success | edit | 4 |
| HLE | OpenClaw | success | python | 212 |
| HLE | OpenClaw | success | read | 86 |
| HLE | OpenClaw | success | search | 240 |
| HLE | OpenClaw | success | tool | 34 |
| HLE | OpenClaw | success | web_fetch | 408 |
| HLE | OpenClaw | success | write | 36 |
| HLE | OpenClaw | unknown | bash | 32 |
| HLE | OpenClaw | unknown | python | 16 |
| HLE | OpenClaw | unknown | read | 1 |
| HLE | OpenClaw | unknown | search | 27 |
| HLE | OpenClaw | unknown | tool | 13 |
| HLE | OpenClaw | unknown | web_fetch | 51 |
| HLE | OpenClaw | unknown | write | 1 |
| HLE | OpenCode | failure | bash | 460 |
| HLE | OpenCode | failure | edit | 3 |
| HLE | OpenCode | failure | glob | 8 |
| HLE | OpenCode | failure | image | 1 |
| HLE | OpenCode | failure | invalid | 10 |
| HLE | OpenCode | failure | python | 693 |
| HLE | OpenCode | failure | read | 53 |
| HLE | OpenCode | failure | search | 82 |
| HLE | OpenCode | failure | skill | 3 |
| HLE | OpenCode | failure | task | 99 |
| HLE | OpenCode | failure | web_fetch | 2200 |
| HLE | OpenCode | failure | write | 47 |
| HLE | OpenCode | success | bash | 145 |
| HLE | OpenCode | success | edit | 4 |
| HLE | OpenCode | success | glob | 1 |
| HLE | OpenCode | success | image | 1 |
| HLE | OpenCode | success | invalid | 7 |
| HLE | OpenCode | success | python | 389 |
| HLE | OpenCode | success | read | 39 |
| HLE | OpenCode | success | search | 9 |
| HLE | OpenCode | success | skill | 2 |
| HLE | OpenCode | success | task | 36 |
| HLE | OpenCode | success | web_fetch | 784 |
| HLE | OpenCode | success | write | 55 |
| HLE | OpenCode | unknown | bash | 1 |
| HLE | OpenCode | unknown | glob | 2 |
| HLE | OpenCode | unknown | image | 2 |
| HLE | OpenCode | unknown | python | 3 |
| HLE | OpenCode | unknown | read | 1 |
| HLE | OpenCode | unknown | task | 1 |
| HLE | OpenCode | unknown | web_fetch | 1 |
| IMO | OpenClaw | failure | bash | 93 |
| IMO | OpenClaw | failure | edit | 11 |
| IMO | OpenClaw | failure | python | 904 |
| IMO | OpenClaw | failure | read | 26 |
| IMO | OpenClaw | failure | search | 197 |
| IMO | OpenClaw | failure | tool | 116 |
| IMO | OpenClaw | failure | web_fetch | 83 |
| IMO | OpenClaw | failure | write | 76 |
| IMO | OpenClaw | success | bash | 28 |
| IMO | OpenClaw | success | edit | 8 |
| IMO | OpenClaw | success | python | 606 |
| IMO | OpenClaw | success | read | 8 |
| IMO | OpenClaw | success | search | 55 |
| IMO | OpenClaw | success | tool | 20 |
| IMO | OpenClaw | success | web_fetch | 20 |
| IMO | OpenClaw | success | write | 58 |
| IMO | OpenCode | failure | bash | 58 |
| IMO | OpenCode | failure | edit | 2 |
| IMO | OpenCode | failure | invalid | 9 |
| IMO | OpenCode | failure | python | 1416 |
| IMO | OpenCode | failure | read | 10 |
| IMO | OpenCode | failure | search | 11 |
| IMO | OpenCode | failure | task | 12 |
| IMO | OpenCode | failure | tool | 174 |
| IMO | OpenCode | failure | web_fetch | 441 |
| IMO | OpenCode | failure | write | 69 |
| IMO | OpenCode | success | bash | 52 |
| IMO | OpenCode | success | edit | 3 |
| IMO | OpenCode | success | invalid | 10 |
| IMO | OpenCode | success | python | 1111 |
| IMO | OpenCode | success | read | 11 |
| IMO | OpenCode | success | search | 2 |
| IMO | OpenCode | success | skill | 1 |
| IMO | OpenCode | success | task | 3 |
| IMO | OpenCode | success | tool | 213 |
| IMO | OpenCode | success | web_fetch | 170 |
| IMO | OpenCode | success | write | 91 |
| MMMU-Pro | OpenClaw | failure | bash | 118 |
| MMMU-Pro | OpenClaw | failure | edit | 7 |
| MMMU-Pro | OpenClaw | failure | python | 301 |
| MMMU-Pro | OpenClaw | failure | read | 24 |
| MMMU-Pro | OpenClaw | failure | search | 428 |
| MMMU-Pro | OpenClaw | failure | tool | 30 |
| MMMU-Pro | OpenClaw | failure | web_fetch | 783 |
| MMMU-Pro | OpenClaw | failure | write | 25 |
| MMMU-Pro | OpenClaw | success | bash | 231 |
| MMMU-Pro | OpenClaw | success | edit | 3 |
| MMMU-Pro | OpenClaw | success | python | 1215 |
| MMMU-Pro | OpenClaw | success | read | 42 |
| MMMU-Pro | OpenClaw | success | search | 473 |
| MMMU-Pro | OpenClaw | success | tool | 92 |
| MMMU-Pro | OpenClaw | success | web_fetch | 646 |
| MMMU-Pro | OpenClaw | success | write | 87 |
| MMMU-Pro | OpenClaw | unknown | bash | 155 |
| MMMU-Pro | OpenClaw | unknown | edit | 2 |
| MMMU-Pro | OpenClaw | unknown | python | 157 |
| MMMU-Pro | OpenClaw | unknown | read | 15 |
| MMMU-Pro | OpenClaw | unknown | search | 216 |
| MMMU-Pro | OpenClaw | unknown | tool | 62 |
| MMMU-Pro | OpenClaw | unknown | web_fetch | 234 |
| MMMU-Pro | OpenClaw | unknown | write | 15 |
| MMMU-Pro | OpenCode | failure | bash | 246 |
| MMMU-Pro | OpenCode | failure | edit | 4 |
| MMMU-Pro | OpenCode | failure | glob | 4 |
| MMMU-Pro | OpenCode | failure | image | 20 |
| MMMU-Pro | OpenCode | failure | invalid | 11 |
| MMMU-Pro | OpenCode | failure | python | 997 |
| MMMU-Pro | OpenCode | failure | read | 185 |
| MMMU-Pro | OpenCode | failure | search | 29 |
| MMMU-Pro | OpenCode | failure | skill | 2 |
| MMMU-Pro | OpenCode | failure | task | 60 |
| MMMU-Pro | OpenCode | failure | web_fetch | 1041 |
| MMMU-Pro | OpenCode | failure | write | 34 |
| MMMU-Pro | OpenCode | success | bash | 288 |
| MMMU-Pro | OpenCode | success | edit | 2 |
| MMMU-Pro | OpenCode | success | glob | 8 |
| MMMU-Pro | OpenCode | success | image | 24 |
| MMMU-Pro | OpenCode | success | invalid | 9 |
| MMMU-Pro | OpenCode | success | python | 1814 |
| MMMU-Pro | OpenCode | success | read | 154 |
| MMMU-Pro | OpenCode | success | search | 53 |
| MMMU-Pro | OpenCode | success | skill | 1 |
| MMMU-Pro | OpenCode | success | task | 53 |
| MMMU-Pro | OpenCode | success | web_fetch | 1047 |
| MMMU-Pro | OpenCode | success | write | 62 |
| MMMU-Pro | OpenCode | unknown | bash | 211 |
| MMMU-Pro | OpenCode | unknown | edit | 2 |
| MMMU-Pro | OpenCode | unknown | invalid | 7 |
| MMMU-Pro | OpenCode | unknown | python | 79 |
| MMMU-Pro | OpenCode | unknown | read | 3 |
| MMMU-Pro | OpenCode | unknown | search | 10 |
| MMMU-Pro | OpenCode | unknown | web_fetch | 65 |
| MMMU-Pro | OpenCode | unknown | write | 4 |

## Output Files

- `source_manifest.csv`
- `trajectory_metrics.csv`
- `action_counts_by_outcome.csv`
- `action_transitions_by_outcome.csv`
- `entropy_token_summary_by_outcome.csv`
- `tool_type_counts_by_outcome.csv`
- `tool_type_transitions_by_outcome.csv`
- `failure_case_summary.csv`
- `extraction_failure_log.csv`
